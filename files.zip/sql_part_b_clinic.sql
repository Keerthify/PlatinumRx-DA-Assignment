-- =============================================================
-- SQL PART B: Clinic Management System
-- Author: [Your Name]
-- =============================================================

-- ---------------------------------------------------------------
-- Q1. Revenue from each sales channel in a given year
-- ---------------------------------------------------------------
-- Replace :year with the target year (e.g., 2021)

SELECT
    sales_channel,
    SUM(amount) AS total_revenue
FROM clinic_sales
WHERE YEAR(datetime) = :year        -- e.g., 2021
GROUP BY sales_channel
ORDER BY total_revenue DESC;


-- ---------------------------------------------------------------
-- Q2. Top 10 most valuable customers for a given year
-- ---------------------------------------------------------------
-- "Most valuable" = highest total spend across all clinics.

SELECT
    c.uid,
    c.name,
    c.mobile,
    SUM(cs.amount) AS total_spend
FROM customer c
JOIN clinic_sales cs ON c.uid = cs.uid
WHERE YEAR(cs.datetime) = :year     -- e.g., 2021
GROUP BY c.uid, c.name, c.mobile
ORDER BY total_spend DESC
LIMIT 10;


-- ---------------------------------------------------------------
-- Q3. Month-wise revenue, expense, profit, and status
--     for a given year
-- ---------------------------------------------------------------
-- profit = revenue - expense
-- status = 'profitable' if profit > 0, else 'not-profitable'

WITH monthly_revenue AS (
    SELECT
        MONTH(datetime) AS month_num,
        SUM(amount)     AS revenue
    FROM clinic_sales
    WHERE YEAR(datetime) = :year
    GROUP BY MONTH(datetime)
),
monthly_expense AS (
    SELECT
        MONTH(datetime) AS month_num,
        SUM(amount)     AS expense
    FROM expenses
    WHERE YEAR(datetime) = :year
    GROUP BY MONTH(datetime)
)
SELECT
    COALESCE(r.month_num, e.month_num)          AS month_num,
    COALESCE(r.revenue, 0)                       AS revenue,
    COALESCE(e.expense, 0)                       AS expense,
    COALESCE(r.revenue, 0) - COALESCE(e.expense, 0) AS profit,
    CASE
        WHEN COALESCE(r.revenue, 0) - COALESCE(e.expense, 0) > 0
        THEN 'profitable'
        ELSE 'not-profitable'
    END AS status
FROM monthly_revenue  r
FULL OUTER JOIN monthly_expense e ON r.month_num = e.month_num
ORDER BY month_num;

-- Note: MySQL doesn't support FULL OUTER JOIN natively.
-- Use UNION of LEFT + RIGHT JOIN instead if on MySQL.


-- ---------------------------------------------------------------
-- Q4. For each city, find the most profitable clinic for a given month
-- ---------------------------------------------------------------
-- profit per clinic = revenue - expense for that clinic

WITH clinic_profit AS (
    SELECT
        cl.cid,
        cl.clinic_name,
        cl.city,
        COALESCE(SUM(cs.amount), 0)                     AS revenue,
        COALESCE(SUM(ex.total_expense), 0)              AS expense,
        COALESCE(SUM(cs.amount), 0)
            - COALESCE(SUM(ex.total_expense), 0)        AS profit
    FROM clinics cl
    LEFT JOIN clinic_sales cs
        ON cl.cid = cs.cid
        AND YEAR(cs.datetime)  = :year
        AND MONTH(cs.datetime) = :month
    LEFT JOIN (
        SELECT cid, SUM(amount) AS total_expense
        FROM expenses
        WHERE YEAR(datetime)  = :year
          AND MONTH(datetime) = :month
        GROUP BY cid
    ) ex ON cl.cid = ex.cid
    GROUP BY cl.cid, cl.clinic_name, cl.city
),
ranked AS (
    SELECT
        *,
        RANK() OVER (PARTITION BY city ORDER BY profit DESC) AS rnk
    FROM clinic_profit
)
SELECT
    city,
    cid,
    clinic_name,
    revenue,
    expense,
    profit AS highest_profit
FROM ranked
WHERE rnk = 1
ORDER BY city;


-- ---------------------------------------------------------------
-- Q5. For each state, find the second least profitable clinic
--     for a given month
-- ---------------------------------------------------------------
-- "Second least profitable" = DENSE_RANK() ASC, pick rank = 2

WITH clinic_profit AS (
    SELECT
        cl.cid,
        cl.clinic_name,
        cl.state,
        COALESCE(SUM(cs.amount), 0)                     AS revenue,
        COALESCE(SUM(ex.total_expense), 0)              AS expense,
        COALESCE(SUM(cs.amount), 0)
            - COALESCE(SUM(ex.total_expense), 0)        AS profit
    FROM clinics cl
    LEFT JOIN clinic_sales cs
        ON cl.cid = cs.cid
        AND YEAR(cs.datetime)  = :year
        AND MONTH(cs.datetime) = :month
    LEFT JOIN (
        SELECT cid, SUM(amount) AS total_expense
        FROM expenses
        WHERE YEAR(datetime)  = :year
          AND MONTH(datetime) = :month
        GROUP BY cid
    ) ex ON cl.cid = ex.cid
    GROUP BY cl.cid, cl.clinic_name, cl.state
),
ranked AS (
    SELECT
        *,
        DENSE_RANK() OVER (PARTITION BY state ORDER BY profit ASC) AS rnk
    FROM clinic_profit
)
SELECT
    state,
    cid,
    clinic_name,
    revenue,
    expense,
    profit AS second_least_profit
FROM ranked
WHERE rnk = 2
ORDER BY state;
