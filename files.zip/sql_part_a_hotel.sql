-- =============================================================
-- SQL PART A: Hotel Management System
-- Author: [Your Name]
-- =============================================================

-- ---------------------------------------------------------------
-- Q1. For every user, get the user_id and last booked room_no
-- ---------------------------------------------------------------
-- Approach: Use ROW_NUMBER() to rank bookings per user by date DESC,
-- then pick rank = 1 (the most recent booking).

SELECT
    u.user_id,
    b.room_no AS last_booked_room_no
FROM users u
JOIN (
    SELECT
        user_id,
        room_no,
        ROW_NUMBER() OVER (
            PARTITION BY user_id
            ORDER BY booking_date DESC
        ) AS rn
    FROM bookings
) b ON u.user_id = b.user_id AND b.rn = 1;

-- Edge case: Users who have never made a booking will not appear.
-- To include them, switch to LEFT JOIN:
-- SELECT u.user_id, b.room_no AS last_booked_room_no
-- FROM users u
-- LEFT JOIN (...) b ON u.user_id = b.user_id AND b.rn = 1;


-- ---------------------------------------------------------------
-- Q2. Get booking_id and total billing amount of every booking
--     created in November 2021
-- ---------------------------------------------------------------
-- Approach: Join bookings → booking_commercials → items to compute
-- bill = SUM(item_rate * item_quantity) per booking.
-- Filter booking_date to November 2021.

SELECT
    b.booking_id,
    SUM(i.item_rate * bc.item_quantity) AS total_billing_amount
FROM bookings b
JOIN booking_commercials bc ON b.booking_id = bc.booking_id
JOIN items i ON bc.item_id = i.item_id
WHERE
    YEAR(b.booking_date)  = 2021
    AND MONTH(b.booking_date) = 11
GROUP BY b.booking_id;


-- ---------------------------------------------------------------
-- Q3. Get bill_id and bill amount of all bills raised in Oct 2021
--     having bill amount > 1000
-- ---------------------------------------------------------------
-- Approach: Aggregate per bill_id across booking_commercials.
-- Filter bill_date to October 2021, then filter by HAVING.

SELECT
    bc.bill_id,
    SUM(i.item_rate * bc.item_quantity) AS bill_amount
FROM booking_commercials bc
JOIN items i ON bc.item_id = i.item_id
WHERE
    YEAR(bc.bill_date)  = 2021
    AND MONTH(bc.bill_date) = 10
GROUP BY bc.bill_id
HAVING SUM(i.item_rate * bc.item_quantity) > 1000;


-- ---------------------------------------------------------------
-- Q4. Most ordered and least ordered item of each month in 2021
-- ---------------------------------------------------------------
-- Approach: Calculate total quantity ordered per item per month.
-- Use RANK() to find both the top and bottom ranked items.
-- RANK() (not ROW_NUMBER) handles ties correctly.

WITH monthly_item_totals AS (
    SELECT
        MONTH(bc.bill_date)         AS order_month,
        bc.item_id,
        i.item_name,
        SUM(bc.item_quantity)       AS total_quantity
    FROM booking_commercials bc
    JOIN items i ON bc.item_id = i.item_id
    WHERE YEAR(bc.bill_date) = 2021
    GROUP BY MONTH(bc.bill_date), bc.item_id, i.item_name
),
ranked AS (
    SELECT
        order_month,
        item_name,
        total_quantity,
        RANK() OVER (PARTITION BY order_month ORDER BY total_quantity DESC) AS rank_desc,
        RANK() OVER (PARTITION BY order_month ORDER BY total_quantity ASC)  AS rank_asc
    FROM monthly_item_totals
)
SELECT
    order_month,
    MAX(CASE WHEN rank_desc = 1 THEN item_name END) AS most_ordered_item,
    MAX(CASE WHEN rank_asc  = 1 THEN item_name END) AS least_ordered_item
FROM ranked
WHERE rank_desc = 1 OR rank_asc = 1
GROUP BY order_month
ORDER BY order_month;


-- ---------------------------------------------------------------
-- Q5. Customers with the second highest bill value of each month
--     in year 2021
-- ---------------------------------------------------------------
-- Approach: 
--   1. Compute per-user, per-month total bill.
--   2. Rank using DENSE_RANK() so that ties share the same rank
--      and rank 2 genuinely means "second highest".

WITH user_monthly_bills AS (
    SELECT
        u.user_id,
        u.name,
        MONTH(bc.bill_date)         AS bill_month,
        SUM(i.item_rate * bc.item_quantity) AS total_bill
    FROM users u
    JOIN bookings b        ON u.user_id    = b.user_id
    JOIN booking_commercials bc ON b.booking_id = bc.booking_id
    JOIN items i           ON bc.item_id   = i.item_id
    WHERE YEAR(bc.bill_date) = 2021
    GROUP BY u.user_id, u.name, MONTH(bc.bill_date)
),
ranked_users AS (
    SELECT
        *,
        DENSE_RANK() OVER (
            PARTITION BY bill_month
            ORDER BY total_bill DESC
        ) AS bill_rank
    FROM user_monthly_bills
)
SELECT
    bill_month,
    user_id,
    name,
    total_bill AS second_highest_bill
FROM ranked_users
WHERE bill_rank = 2
ORDER BY bill_month;
