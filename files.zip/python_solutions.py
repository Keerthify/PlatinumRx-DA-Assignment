# ================================================================
# PYTHON PROFICIENCY — SOLUTIONS
# Author: [Your Name]
# ================================================================


# ---------------------------------------------------------------
# Q1. Convert minutes to human-readable format
# ---------------------------------------------------------------

def minutes_to_human_readable(total_minutes: int) -> str:
    """
    Convert a number of minutes into a human-readable string.

    Examples:
        130  → "2 hrs 10 minutes"
        110  → "1 hr 50 minutes"
        60   → "1 hr 0 minutes"
        45   → "45 minutes"
        0    → "0 minutes"
        -10  → raises ValueError
    """
    if not isinstance(total_minutes, int):
        raise TypeError(f"Expected int, got {type(total_minutes).__name__}")
    if total_minutes < 0:
        raise ValueError("Minutes cannot be negative")

    hours   = total_minutes // 60
    minutes = total_minutes % 60

    if hours == 0:
        return f"{minutes} minutes"
    elif hours == 1:
        return f"{hours} hr {minutes} minutes"
    else:
        return f"{hours} hrs {minutes} minutes"


# --- Test cases ---
test_cases = [130, 110, 60, 45, 0, 1, 120, 999]
for t in test_cases:
    print(f"{t:>5}  →  {minutes_to_human_readable(t)}")

# Output:
#   130  →  2 hrs 10 minutes
#   110  →  1 hr 50 minutes
#    60  →  1 hr 0 minutes
#    45  →  45 minutes
#     0  →  0 minutes
#     1  →  1 minutes
#   120  →  2 hrs 0 minutes
#   999  →  16 hrs 39 minutes


print("\n" + "="*50 + "\n")


# ---------------------------------------------------------------
# Q2. Remove duplicates from a string using a loop (preserve order)
# ---------------------------------------------------------------

def remove_duplicates(s: str) -> str:
    """
    Remove all duplicate characters from a string, preserving the
    order of first occurrence. Uses a loop (no built-in set tricks).

    Examples:
        "abracadabra" → "abrcd"
        "hello"       → "helo"
        "aabbcc"      → "abc"
        ""            → ""
    """
    seen   = []   # tracks chars already added (preserves order)
    result = []   # builds the output

    for char in s:
        if char not in seen:   # loop-based membership check
            seen.append(char)
            result.append(char)

    return "".join(result)


# --- Test cases ---
test_strings = [
    "abracadabra",
    "hello",
    "aabbcc",
    "programming",
    "Python",
    "",
    "aaaa",
    "abcABC",          # case-sensitive: 'a' ≠ 'A'
    "hello world",     # spaces are characters too
]

for s in test_strings:
    print(f'Input : "{s}"')
    print(f'Output: "{remove_duplicates(s)}"')
    print()
